package com.organisation.logistics.orderproducer;

import com.organisation.logistics.orderproducer.producer.OrderProducerThread;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutionException;

public class App {
    private static final Logger LOG = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        OrderProducerThread orderProducer = new OrderProducerThread("127.0.0.1:29092");
        LOG.info("Starting Order Producer Application");
        orderProducer.setTopic("order.create");
        orderProducer.run();
    }
}