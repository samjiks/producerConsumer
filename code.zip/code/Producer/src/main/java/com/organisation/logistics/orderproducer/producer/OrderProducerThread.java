package com.organisation.logistics.orderproducer.producer;

import com.organisation.logistics.orderproducer.models.OrderCreate;
import com.organisation.logistics.orderproducer.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class OrderProducerThread extends OrderProducer implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(OrderProducerThread.class);
    private volatile boolean running = true;

    public OrderProducerThread(String bootStrapServer) {
        super(bootStrapServer);
    }

    public void terminate() {
        running = false;
    }


    @Override
    public void run () {
        // Runs on a single thread at the moment
        while (running) try {
            OrderService service = new OrderService();
            OrderCreate orderCreate = service.create();
            put(orderCreate.getTimestamp(), orderCreate.toString());
            // Sleep for sometime to create the next order, increase or decrease at your rate
            Thread.sleep(7000);
        } catch (Exception e) {
            logger.error(e.getMessage());
            running = false;
        }
    }

}
