package com.organisation.logistics.orderproducer.serializer;

// TODO: Create a JSON Serializer to get value for Producer to JSON
class JSONSerializer {

}