package com.organisation.logistics.orderproducer.producer;

import com.organisation.logistics.orderproducer.models.Message;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class OrderProducer {

    private final KafkaProducer<String, String> mProducer;
    private static final Logger logger = LoggerFactory.getLogger(OrderProducer.class);
    private String topic;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    private Properties producerProps(String bootStrapServer){
        String serializer = StringSerializer.class.getName();
        Properties props = new Properties();
        props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootStrapServer);
        props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, serializer);
        // TODO: The VALUE_SERIALIZER_CLASS_CONFIG from StringSerializer should change to JSONSerializer
        props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, serializer);
        return props;
    }

    public OrderProducer(String bootStrapServer){
        Properties props = producerProps(bootStrapServer);
        mProducer = new KafkaProducer<String, String>(props);
        logger.info("Producer Initialized");
    }

    private Boolean isTopicRegistered(){
        return topic != null;
    }

    public void put(String key, String value) throws Exception {
        if (!isTopicRegistered()) {
            throw new Exception("Please set Topic using setTopic()!");
        }
        // TODO: Convert Message Value to JSONSerializer, and send as JSON data
        Message message = new Message(key, value);
        System.out.println(message.toString());
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, message.getKey(),
                message.getValue());
        // Synchronous Mode
        mProducer.send(record, (recordMetadata, e) -> {
            if (e != null) {
                logger.error("Error While Producing" + e.getMessage());
                mProducer.close();
                return;
            }

        System.out.println("Received New Data " +
                " Topic: " + recordMetadata.topic()  +
                " Offset: " + recordMetadata.offset() +
                " Partition: " + recordMetadata.partition() + "\n"
            );
        }).get();
    }
}
