package com.organisation.logistics.orderproducer.helper;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class RandomDataGenerator {

    public String getCustomerId(){
        Random random = new Random();
        List<String> mockCustomerIds = Arrays.asList("244223", "444223", "544234", "544223");
        int randomItem = random.nextInt(mockCustomerIds.size());
        String customerId;
        customerId = mockCustomerIds.get(randomItem);
        return customerId;
    }

    public String getOrderId(){
        Random random = new Random();
        List<String> mockOrderIds = Arrays.asList("1234244", "14355667", "23535562", "111344445");
        int randomItem = random.nextInt(mockOrderIds.size());
        String orderId;
        orderId = mockOrderIds.get(randomItem);
        return orderId;
    }
}
