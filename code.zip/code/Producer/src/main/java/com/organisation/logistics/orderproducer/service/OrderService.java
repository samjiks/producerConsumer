package com.organisation.logistics.orderproducer.service;

import com.organisation.logistics.orderproducer.helper.RandomDataGenerator;
import com.organisation.logistics.orderproducer.models.OrderCreate;

public class OrderService {

    public OrderCreate create(){
        RandomDataGenerator generator = new RandomDataGenerator();
        OrderCreate createOrder;
        createOrder = new OrderCreate(generator.getCustomerId(),
                generator.getOrderId(), 4,
                "Created", generator.getOrderId());
        // change orderid to timestamp;
        return createOrder;
    }
}
