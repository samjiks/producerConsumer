package com.organisation.logistics.orderproducer.models;

public class OrderCreate {

    private String customerId;
    private String orderId;
    private int itemsCount;
    private String orderStatus;
    private String timestamp;
    // create orderPrice type Double

    public String getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "OrderCreate{" +
                "customerId='" + customerId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", itemsCount=" + itemsCount +
                ", orderStatus='" + orderStatus + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }

    public OrderCreate(String customerId, String orderId, int itemsCount,
                       String orderStatus, String timestamp) {
        this.customerId = customerId;
        this.orderId = orderId;
        this.itemsCount = itemsCount;
        this.orderStatus = orderStatus;
        this.timestamp = timestamp;
    }

}
